# ADEYBINGO — Google AI Studio Starter

React + TypeScript + Vite prototype for an Amharic-first Telegram Mini App.

## Run
1. Install Node.js 20+.
2. Extract the ZIP and open the folder.
3. Run `npm install`
4. Run `npm run dev`
5. Open the localhost URL shown by Vite.

## Use with Google AI Studio
Open Google AI Studio Build mode. Import/upload this project if your workspace supports ZIP import; otherwise extract it and provide the files as project context. Paste `GOOGLE_AI_STUDIO_PROMPT.md` and ask the agent to inspect and improve the existing project incrementally.

## Included
- Responsive green Bingo UI
- Animated number caller and recent-call history
- Random 5x5 B-I-N-G-O card with free center
- Up to four local demo cards
- Mark called numbers
- Amharic/English label toggle
- Demo-only balance, room and referral/support previews

## Not included
This is not a production game. It has no real Telegram authentication, multiplayer backend, Firebase integration, payment processing, withdrawals, cash prizes or server-side winner verification. All balances and player counts are illustrative. Keep real-money functions disabled until qualified Ethiopian legal/compliance review, required licensing and payment-provider approvals are complete.

Never put Telegram bot tokens, Firebase Admin credentials or payment secrets in browser code. Future privileged actions must run on a trusted backend with strict rules, atomic ledger operations, idempotency, audit logs and server-side game verification.
