# Google AI Studio prompt — ADEYBINGO

Act as a senior React/TypeScript product engineer. Inspect this existing project first. Preserve its React + Vite structure, existing working UI and green visual identity. Do not replace the app wholesale. Make incremental, buildable changes and explain each changed file.

## Product
ADEYBINGO is an Amharic-first Telegram Mini App Bingo experience for mobile. The visual direction is a premium green casual game: glossy 3D balls, warm gold accents, soft shadows, rounded surfaces, polished motion, responsive layouts and Telegram safe-area support. Amharic is default; English is optional.

## Proposed configurable game rules
- Maximum 600 cards in a room.
- Maximum 4 cards per player.
- Proposed card price 10 ETB.
- Proposed 60-second lobby countdown.
- Proposed minimum 3 distinct eligible players.
- Proposed referral credits: inviter 20 ETB and invitee 15 ETB.
Treat these as product requirements to model/configure, not permission to process money.

## Frontend milestones
1. Home dashboard and room list.
2. Lobby with capacity, countdown, player count and card selection.
3. Bingo card picker, one to four cards per player.
4. Live game with 5x5 B-I-N-G-O card, free center, manual and optional auto marking, called number and call history.
5. Smooth ball entrance, cell marking feedback, reduced-motion support and winner celebration preview.
6. Wallet, referrals, profile, support, terms, game history and notification screens.
7. Amharic/English language switch and sound controls.
8. Clear loading, offline, reconnecting, empty, error and success states.

## Security and compliance boundaries
Do not implement live deposits, redeemable balances, cash prizes or withdrawals in this prototype. Label balances and player counts as demo data. Never treat payment screenshots as proof of payment. Never trust client-side balances, card claims, number draws or winner claims. Do not expose Firebase Admin credentials, Telegram bot tokens or payment-provider secrets in frontend code.

For a later approved backend: validate Telegram Mini App initData server-side; use Cloud Functions or another trusted server for game and wallet actions; implement atomic ledger transactions, idempotency keys, immutable audit logs and strict Firestore Security Rules; use server-authoritative, auditable random draws and winner verification. Confirm Ethiopian legal/licensing requirements and Telegram/payment provider policies before any real-money launch. Include age verification and responsible-gaming controls.

## Engineering
Use strict TypeScript, reusable components, typed models, performant animations, accessibility and mobile-first design. Add tests for card generation, number ranges and card limits. Ensure each visible control works or is clearly marked as coming soon. Run the production build and report errors honestly.

## Deliver
Return a working project, list files changed, exact run/build commands, known limitations and next milestone. Do not claim backend, Telegram or payment integration is complete unless actually implemented and tested.
